package com.adrict99.weather.ui

import com.adrict99.weather.ui.common.BaseViewModel
import javax.inject.Inject

class MainViewModel @Inject constructor(): BaseViewModel() {

}